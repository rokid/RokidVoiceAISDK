var searchData=
[
  ['trigger',['trigger',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a1449f45dd812d2b5d5d7e925a279c58e',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerconfirm',['triggerConfirm',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#ab4f74a55ab1df557fd25b0d4922ca7b2',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerlength',['triggerLength',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a10a78409d84e8803ded958dd0d52b2de',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerstart',['triggerStart',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a1c13171e2097599d7f241fb601c78ec6',1,'com::rokid::voiceai::VoiceOptions']]]
];
