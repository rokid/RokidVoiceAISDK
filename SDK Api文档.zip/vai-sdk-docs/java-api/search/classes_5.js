var searchData=
[
  ['语音交互类',['语音交互类',['../class_xE8_xAF_xAD_xE9_x9F_xB3_xE4_xBA_xA4_xE4_xBA_x92_xE7_xB1_xBB.html',1,'']]],
  ['语音识别结果回调',['语音识别结果回调',['../class_xE8_xAF_xAD_xE9_x9F_xB3_xE8_xAF_x86_xE5_x88_xAB_xE7_xBB_x93_xE6_x9E_x9C_xE5_x9B_x9E_xE8_xB0_x83.html',1,'']]]
];
