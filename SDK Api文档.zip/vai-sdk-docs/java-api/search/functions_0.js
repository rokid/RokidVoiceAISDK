var searchData=
[
  ['destroy',['destroy',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a8d56075d025f4b5bebad5bd9a8213e53',1,'com::rokid::voiceai::VoiceAI']]]
];
