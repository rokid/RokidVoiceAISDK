var searchData=
[
  ['actioncallback',['ActionCallback',['../interfacecom_1_1rokid_1_1voiceai_1_1ActionCallback.html',1,'com::rokid::voiceai']]],
  ['audio_5fcodec_5fmp3',['AUDIO_CODEC_MP3',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a89730266f1384324816313e5d1840d76',1,'com::rokid::voiceai::VoiceAI']]],
  ['audio_5fcodec_5fopu',['AUDIO_CODEC_OPU',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#ab3981af434811baeaef8d1f86b9f8145',1,'com::rokid::voiceai::VoiceAI']]],
  ['audio_5fcodec_5fopu2',['AUDIO_CODEC_OPU2',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a51b5ec55c0b11a183db0f9670bc6d451',1,'com::rokid::voiceai::VoiceAI']]],
  ['audio_5fcodec_5fpcm',['AUDIO_CODEC_PCM',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#ad8944a824b9ebe3893e21b8bc4f64696',1,'com::rokid::voiceai::VoiceAI']]]
];
