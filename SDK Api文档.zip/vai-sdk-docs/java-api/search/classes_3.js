var searchData=
[
  ['ttscallback',['TtsCallback',['../interfacecom_1_1rokid_1_1voiceai_1_1TtsCallback.html',1,'com::rokid::voiceai']]]
];
