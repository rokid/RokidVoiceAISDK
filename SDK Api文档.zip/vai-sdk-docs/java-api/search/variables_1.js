var searchData=
[
  ['declaimer_5fchild1',['DECLAIMER_CHILD1',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#afcb10fb4478e3e527f0123f6c27321c1',1,'com::rokid::voiceai::VoiceAI']]],
  ['declaimer_5frokid',['DECLAIMER_ROKID',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a06927c7a604cc92c6bae5cc98649ca75',1,'com::rokid::voiceai::VoiceAI']]]
];
