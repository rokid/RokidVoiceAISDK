var searchData=
[
  ['writevoice',['writeVoice',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a1b850b094cdc25d45928d2d49c076891',1,'com.rokid.voiceai.VoiceAI.writeVoice(byte[] data, int offset, int length)'],['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#af73a376427ce4894a845f9d843cd6fae',1,'com.rokid.voiceai.VoiceAI.writeVoice(byte[] data)']]]
];
