var searchData=
[
  ['putasr',['putAsr',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a9a9fbccd0789eb2769293381108a12d9',1,'com::rokid::voiceai::VoiceAI']]]
];
