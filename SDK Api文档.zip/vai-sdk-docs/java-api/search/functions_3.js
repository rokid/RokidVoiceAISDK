var searchData=
[
  ['isactive',['isActive',['../classcom_1_1rokid_1_1voiceai_1_1Session.html#a3691ade7c2b0f56a4058b872f1a95610',1,'com::rokid::voiceai::Session']]],
  ['isnative',['isNative',['../classcom_1_1rokid_1_1voiceai_1_1Session.html#ae161e92720dbd2413e7dfe218e60acab',1,'com::rokid::voiceai::Session']]]
];
