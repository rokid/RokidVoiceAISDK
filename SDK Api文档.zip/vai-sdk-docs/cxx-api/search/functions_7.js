var searchData=
[
  ['read',['read',['../classrokid_1_1TtsStream.html#a21f54b4388909013b121f4af73d438c6',1,'rokid::TtsStream']]]
];
