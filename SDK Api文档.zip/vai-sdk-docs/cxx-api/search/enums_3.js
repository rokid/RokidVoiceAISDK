var searchData=
[
  ['skillform',['SkillForm',['../classrokid_1_1VoiceAI.html#aa33d3de83653f5537bdc83a198939553',1,'rokid::VoiceAI']]]
];
