var searchData=
[
  ['writevoice',['writeVoice',['../classrokid_1_1VoiceAI.html#a0c484ef56120b022fb81efca680f6d3f',1,'rokid::VoiceAI']]]
];
