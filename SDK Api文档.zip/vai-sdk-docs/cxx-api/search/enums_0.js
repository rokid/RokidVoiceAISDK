var searchData=
[
  ['audiocodec',['AudioCodec',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38',1,'rokid::VoiceAI']]]
];
