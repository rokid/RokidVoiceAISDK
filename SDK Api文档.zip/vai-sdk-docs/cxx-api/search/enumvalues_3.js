var searchData=
[
  ['mp3',['MP3',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38a27bcd310c52f6445cf4b93b90f52f5ef',1,'rokid::VoiceAI']]]
];
