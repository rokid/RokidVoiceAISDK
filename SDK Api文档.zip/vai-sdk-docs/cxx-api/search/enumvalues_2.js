var searchData=
[
  ['intermedia_5fasr',['INTERMEDIA_ASR',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a3a78554351b704350c60e3259f50230a',1,'rokid::VoiceAI']]]
];
