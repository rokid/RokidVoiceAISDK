var searchData=
[
  ['getappid',['getAppId',['../classrokid_1_1VoiceAI_1_1Session.html#a46065f3f79808b7d2602dc1c7a66e0bb',1,'rokid::VoiceAI::Session']]],
  ['geterror',['getError',['../classrokid_1_1TtsStream.html#a3041fc81ae4a7477dbec1668dcd3f254',1,'rokid::TtsStream']]]
];
