var searchData=
[
  ['endvoice',['endVoice',['../classrokid_1_1VoiceAI.html#a33b4ac447fa80438a2a94b08ed22614f',1,'rokid::VoiceAI']]]
];
