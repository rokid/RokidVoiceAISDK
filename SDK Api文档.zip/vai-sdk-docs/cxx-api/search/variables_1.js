var searchData=
[
  ['isactive',['isActive',['../classrokid_1_1VoiceAI_1_1Session.html#a43a530ff1682efbab03ef5ce999e5d68',1,'rokid::VoiceAI::Session']]],
  ['isnative',['isNative',['../classrokid_1_1VoiceAI_1_1Session.html#a1e512ebfda60e3a55089e8ddb2650d8e',1,'rokid::VoiceAI::Session']]]
];
