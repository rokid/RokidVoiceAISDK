var searchData=
[
  ['nativeexit',['nativeExit',['../classrokid_1_1VoiceAI_1_1Session.html#afe2bd48101e2fa463560d8f87fa5bb55',1,'rokid::VoiceAI::Session']]],
  ['newinstance',['newInstance',['../classrokid_1_1VoiceAI.html#a15e6fe62fdec4bcff835efcd7a649804',1,'rokid::VoiceAI']]]
];
