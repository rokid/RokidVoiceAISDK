var searchData=
[
  ['newinstance',['newInstance',['../classrokid_1_1VoiceAI.html#a15e6fe62fdec4bcff835efcd7a649804',1,'rokid::VoiceAI']]]
];
