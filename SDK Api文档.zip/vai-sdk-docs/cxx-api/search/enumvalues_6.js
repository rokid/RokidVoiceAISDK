var searchData=
[
  ['report_5furi',['REPORT_URI',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880af981db5bea2ed4ef261da41b3fbda010',1,'rokid::VoiceAI']]],
  ['rokid',['ROKID',['../classrokid_1_1VoiceAI.html#a0c4b0f3d4851ccccff0ac561b8c6b7a8aa620dcf9de02eff02164cb324e9b8ba0',1,'rokid::VoiceAI']]]
];
