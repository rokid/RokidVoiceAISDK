var searchData=
[
  ['child1',['CHILD1',['../classrokid_1_1VoiceAI.html#a0c4b0f3d4851ccccff0ac561b8c6b7a8a579871369d41c17cb48ffe10a0015e74',1,'rokid::VoiceAI']]],
  ['config',['config',['../classrokid_1_1VoiceAI.html#ad926c5844dfda1ca0c82d63b3eaefee1',1,'rokid::VoiceAI']]],
  ['continuous_5fdialogue',['CONTINUOUS_DIALOGUE',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a657e395ed4ad29ccdd1bfdac28e38757',1,'rokid::VoiceAI']]]
];
