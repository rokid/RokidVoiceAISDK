var searchData=
[
  ['declaimer',['Declaimer',['../classrokid_1_1VoiceAI.html#a0c4b0f3d4851ccccff0ac561b8c6b7a8',1,'rokid::VoiceAI']]]
];
