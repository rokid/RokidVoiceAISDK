var searchData=
[
  ['getappid',['getAppId',['../classrokid_1_1VoiceAI_1_1Session.html#a46065f3f79808b7d2602dc1c7a66e0bb',1,'rokid::VoiceAI::Session']]]
];
